# Let's Move! — Wellness Experience

Estación **Physical Activity** del proyecto *Wellness Experience* (3.er año).

- `index.html` → la presentación (12 diapositivas).
- `guion.html` → el guion de cada expositor (≈ 1:30 cada uno).

## Cómo se usa la presentación
- **→ / espacio / clic**: siguiente · **←**: anterior
- **F**: pantalla completa · **Inicio**: volver a la portada (para el próximo grupo)
- Diapositiva 11: hacé clic en una tarjeta para elegir un hábito · **↺ Reset** para borrar.

## Cambiar nombres o textos
Abrí `index.html` y editá la parte de arriba (`const NAMES` y `const SLIDES`).

Es un sitio estático: no necesita instalar nada ni compilar. En Vercel, el framework es **Other** y no hace falta comando de build.
